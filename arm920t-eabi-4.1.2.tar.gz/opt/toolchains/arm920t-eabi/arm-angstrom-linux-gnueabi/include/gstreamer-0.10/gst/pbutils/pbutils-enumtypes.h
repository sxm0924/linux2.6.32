
/* Generated data (by glib-mkenums) */

#ifndef __GST_INSTALL_ENUM_TYPES_H__
#define __GST_INSTALL_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "install-plugins.h" */
GType gst_install_plugins_return_get_type (void);
#define GST_TYPE_INSTALL_PLUGINS_RETURN (gst_install_plugins_return_get_type())
G_END_DECLS

#endif /* __GST_INSTALL_ENUM_TYPES_H__ */

/* Generated data ends here */

