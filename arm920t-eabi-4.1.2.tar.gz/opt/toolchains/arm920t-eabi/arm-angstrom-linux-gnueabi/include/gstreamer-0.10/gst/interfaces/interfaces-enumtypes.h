
/* Generated data (by glib-mkenums) */

#ifndef __GST_INTERFACES_ENUM_TYPES_H__
#define __GST_INTERFACES_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "colorbalance.h" */
GType gst_color_balance_type_get_type (void);
#define GST_TYPE_COLOR_BALANCE_TYPE (gst_color_balance_type_get_type())

/* enumerations from "mixer.h" */
GType gst_mixer_type_get_type (void);
#define GST_TYPE_MIXER_TYPE (gst_mixer_type_get_type())
GType gst_mixer_message_type_get_type (void);
#define GST_TYPE_MIXER_MESSAGE_TYPE (gst_mixer_message_type_get_type())
GType gst_mixer_flags_get_type (void);
#define GST_TYPE_MIXER_FLAGS (gst_mixer_flags_get_type())

/* enumerations from "mixertrack.h" */
GType gst_mixer_track_flags_get_type (void);
#define GST_TYPE_MIXER_TRACK_FLAGS (gst_mixer_track_flags_get_type())

/* enumerations from "tunerchannel.h" */
GType gst_tuner_channel_flags_get_type (void);
#define GST_TYPE_TUNER_CHANNEL_FLAGS (gst_tuner_channel_flags_get_type())
G_END_DECLS

#endif /* __GST_INTERFACES_ENUM_TYPES_H__ */

/* Generated data ends here */

