
/* Generated data (by glib-mkenums) */

#ifndef __GST_AUDIO_ENUM_TYPES_H__
#define __GST_AUDIO_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "multichannel.h" */
GType gst_audio_channel_position_get_type (void);
#define GST_TYPE_AUDIO_CHANNEL_POSITION (gst_audio_channel_position_get_type())
G_END_DECLS

#endif /* __GST_AUDIO_ENUM_TYPES_H__ */

/* Generated data ends here */

